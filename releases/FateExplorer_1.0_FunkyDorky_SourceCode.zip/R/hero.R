# Hero R6
library(R6)
require(jsonlite)

##' WeaponBase class (abstract base class for weapons)
##' @importFrom R6 R6Class
##' @export
Hero <- R6Class("Hero", public = list(
  
  Name = NA,
  Abilities = NA, 
  Skills = NA,
  CombatSkills = NA,
  ArcaneSkills = NA,
  KarmaSkills  = NA,

  LastAbilityRoll = NA,
  
  
  #' Constructor
  #' @param Weapon name of the weapon (character)
  #' @param Abilities Character abilities (data frame)
  #' @param CombatTecSkills Named list of combat tech skills 
  #' (names are the `combattechID`)
  #' @return `self`
  initialize = function(Weapon = NULL, Abilities = NULL, CombatTecSkills = NULL, ...) {
    if (missing(Weapon)) {
      args <- list(...)
      self$Name <- NA
      self$Type <- NA
      self$Technique <- NA
      self$Range     <- NA
      self$Skill  <- args[["Skill"]]
      self$Damage <- args[["Damage"]]
      self$Modifier  <- 0L
    } else {
      if (is.character(Weapon)) 
        self$RawWeaponData <- GetWeapons(Weapon)
      else 
        self$RawWeaponData <- Weapon
      self$Name      <- self$RawWeaponData[["name"]]
      self$Type      <- .WeaponType[1+ self$RawWeaponData[["armed"]] + !self$RawWeaponData[["clsrng"]] ]
      self$Technique <- self$RawWeaponData[["combattechID"]]
      self$Range     <- self$RawWeaponData[["range"]]
      self$CalcSkill(Abilities, CombatTecSkills)
      self$CalcDamage(Abilities)
      self$Modifier  <- 0L
    }
    
    invisible(self)
  },
  
  
  #' CalcSkill
  #' Computes weapons skill for character
  #' @param CharAbs Data frame of character abilities
  #' @param CombatTecSkill A single value for the combat skill of the weapon's technique
  #' @return `self`
  CalcSkill = function(CharAbs, CombatTecSkill) {
    AtPaSkill  <- GetCombatSkill(self$Name, CharAbs, Skill = CombatTecSkill)
    self$Skill <- list(Attack = AtPaSkill$AT, 
                       Parry = AtPaSkill$PA, 
                       Dodge = ceiling(CharAbs[["ATTR_6"]] / 2))
    return(invisible(self))
  }
))
